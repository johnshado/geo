<?php
  include('./views/result.php');
?>
