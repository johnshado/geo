<?php

class volumes {

  private $radio;

  public function __construct($r) {
    $this->radio = $r;
  }

  function getArea(){
    return 4 * pi() * pow($this->radio,2);
  }
  function getVolumen(){
    return (4 * pi() * pow($this->radio,3))/3;
  }
  function getResult(){
    return '&Aacute;rea:'.$this->getArea().' unidades<sup>2</sup><br>Vol&uacute;men:'.$this->getVolumen().' unidades<sup>3</sup>';
  }
}

$radio = $_POST['radio'];
$volume = new volumes($radio);


?>
<!DOCTYPE html>
<html>
  <meta charset="utf-8">
  <head>
    <title>C&aacute;lculo de &Aacute;reas</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.slim.min.js" charset="utf-8"></script>
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/popper.min.js" charset="utf-8"></script>
    <style>
      *{
        box-sizing: border-box;
      }

      body {
        width: 100%;
        height: 100%;
        padding: 50px;
      }

      header{
        top:0;
      }

      footer{
        bottom:0;
      }

      header, footer {
        position: fixed;
        text-align: center;
      }
    </style>
  </head>
  <body class="container">
    <header class="text-center">
      <h1 >EVIDENCIA 3</h1>
    </header>

    <main class="container-fluid">
      <section class="row">
        <div class="col-md-4">
        </div>
        <div class="col-md-4">
          <div class="card border-primary mb-3" style="max-width: 40rem;">
            <div class="card-header text-primary">
              <h2>Vol&uacute;men Esfera</h2>
            </div>
            <div class="card-body">
              <h3 class="card-title">Resultado</h3>
              <p class="card-text"><h4><?=$volume->getResult();?></h4></p>
            </div>
          </div>

          <a href="./app.php">
            <button type="button" class="btn btn-dark form-control">Home</button>
          </a>
        </div>
        <div class="col-md-4">
        </div>
      </section>
    </main>
    <footer class="text-center">
      &copy; 2022
    </footer>
  </body>
</html>
