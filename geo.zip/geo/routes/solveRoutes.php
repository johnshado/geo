<?php
  include('./controller/resultController.php'); 
?>
