<?php

  class Solve{

    private $altura;
    private $base;

    public function __construct($h,$b){
      $this->altura = $h;
      $this->base = $b;
    }

    function getArea(){
      return $this->altura * $this->base;
    }
    function getPerimetro(){
      return 2 * ($this->altura+$this->base);
    }

    function getResult(){
      return '&Aacute;rea:'.$this->getArea().' unidades<sup>2</sup> <br>Perimetro:'.$this->getPerimetro().' unidades';
    }

  }

  $altura = $_POST['altura'];
  $base = $_POST['base'];
  $sol = new Solve($altura,$base);
?>
<!DOCTYPE html>
<html>
  <meta charset="utf-8">
  <head>
    <title>C&aacute;lculo de &Aacute;rea de un Rect&aacute;ngulo</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.slim.min.js" charset="utf-8"></script>
    <script src="js/bootstrap.bundle.min.js" charset="utf-8"></script>
    <script src="js/popper.min.js" charset="utf-8"></script>
    <style>
      *{
        box-sizing: border-box;
      }

      body {
        width: 100%;
        padding: 50px;
        margin:0;
      }

      header{
        top:0;
        padding: 5px;
      }

      footer{
        bottom:0;
      }

      header, footer {
        position: fixed;
        text-align: center;
      }
    </style>
  </head>
  <body class="container">
    <header class="card border-primary">
      <h1 class="card-header text-dark" style="text-align:center;">EVIDENCIA 3</h1>
    </header>

    <main class="container-fluid">
      <section class="row text-center">
        <div class="col-md-4">

        </div>
        <div class="col-md-4">
          <div class="card border-primary mb-3" style="max-width: 25rem;">
            <div class="card-header text-primary">
              <h2>&Aacute;rea y Per&iacute;metro de un Rect&aacute;ngulo</h2>
            </div>
            <div class="card-body">
              <h3 class="card-title">Resultado</h3>
              <p class="card-text"><h4><?=$sol->getResult();?></h4></p>
            </div>
          </div>

          <a href="./app.php">
            <button type="button" class="btn btn-dark form-control">Home</button>
          </a>
        </div>
        <div class="col-md-4">

        </div>
      </section>
    </main>
    <footer class="text-center">
      &copy; 2022
    </footer>
  </body>
</html>
